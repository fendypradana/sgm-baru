<?php
  header('location:motor.php?module=home'); 
?>
